import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, category, priority } = body

    // Validation
    if (!title || !description || !category || !priority) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    const validCategories = ["account", "transaction", "technical", "general", "complaint"]
    const validPriorities = ["low", "medium", "high", "urgent"]

    if (!validCategories.includes(category) || !validPriorities.includes(priority)) {
      return NextResponse.json({ error: "Invalid category or priority" }, { status: 400 })
    }

    // Create support ticket
    const { data: ticket, error: ticketError } = await supabase
      .from("support_tickets")
      .insert({
        user_id: user.id,
        title: title.trim(),
        description: description.trim(),
        category,
        priority,
        status: "open",
      })
      .select()
      .single()

    if (ticketError) {
      console.error("Ticket creation error:", ticketError)
      return NextResponse.json({ error: "Failed to create support ticket" }, { status: 500 })
    }

    // Create initial message
    const { error: messageError } = await supabase.from("support_messages").insert({
      ticket_id: ticket.id,
      sender_id: user.id,
      sender_type: "user",
      message: description.trim(),
      is_internal: false,
    })

    if (messageError) {
      console.error("Message creation error:", messageError)
      // Don't fail the request if message creation fails
    }

    return NextResponse.json({
      success: true,
      ticket: {
        id: ticket.id,
        ticket_number: ticket.ticket_number,
        title: ticket.title,
        status: ticket.status,
        priority: ticket.priority,
        category: ticket.category,
        created_at: ticket.created_at,
      },
      message: "Support ticket created successfully",
    })
  } catch (error) {
    console.error("Support ticket API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    let query = supabase
      .from("support_tickets")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (status && status !== "all") {
      query = query.eq("status", status)
    }

    const { data: tickets, error } = await query

    if (error) {
      return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 })
    }

    return NextResponse.json({ tickets })
  } catch (error) {
    console.error("Support ticket fetch API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
