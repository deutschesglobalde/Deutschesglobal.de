"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { LanguageSelector } from "@/components/language-selector"
import { ChatSupport } from "@/components/chat-support"
import { AdminLoginModal } from "@/components/admin-login-modal"
import {
  Shield,
  Globe,
  Smartphone,
  TrendingUp,
  CheckCircle,
  ChevronRight,
  Menu,
  X,
  Mail,
  Phone,
  MapPin,
  Clock,
  Star,
  HeadphonesIcon,
  ArrowRight,
  Quote,
  User,
  Building,
  CreditCard,
  Building2,
} from "lucide-react"
import { translations, detectLanguage, type Language } from "@/lib/i18n"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function Page() {
  const [currentView, setCurrentView] = useState("home")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [logoClickCount, setLogoClickCount] = useState(0)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [adminCredentials, setAdminCredentials] = useState({ username: "", password: "" })
  const [adminError, setAdminError] = useState("")
  const [language, setLanguage] = useState<Language>("de")
  const [activeTestimonial, setActiveTestimonial] = useState(0)
  const router = useRouter()

  useEffect(() => {
    setLanguage(detectLanguage())
  }, [])

  const t = translations[language]

  useEffect(() => {
    if (logoClickCount > 0 && logoClickCount < 3) {
      const timer = setTimeout(() => setLogoClickCount(0), 3000)
      return () => clearTimeout(timer)
    }
  }, [logoClickCount])

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleLogoClick = () => {
    setLogoClickCount((prev) => prev + 1)
    if (logoClickCount === 2) {
      setShowAdminLogin(true)
      setLogoClickCount(0)
    }
  }

  const handleOpenAccount = () => {
    router.push("/auth/sign-up")
  }

  const handleSignIn = () => {
    router.push("/auth/login")
  }

  const handleLearnMore = () => {
    setCurrentView("about")
  }

  const handleAdminLogin = async () => {
    if (adminCredentials.username === "admin" && adminCredentials.password === "admin111") {
      const sessionToken = btoa(`admin_session_${Date.now()}_${Math.random()}`)
      document.cookie = `admin_session=${sessionToken}; path=/; secure; samesite=strict`
      document.cookie = `admin_auth=true; path=/; secure; samesite=strict`
      setShowAdminLogin(false)
      setAdminCredentials({ username: "", password: "" })
      setAdminError("")
      router.push("/admin")
    } else {
      setAdminError("Invalid administrative credentials")
      setTimeout(() => setAdminError(""), 3000)
    }
  }

  const navigation = [
    { id: "home", name: language === "de" ? "Startseite" : "Home" },
    { id: "services", name: language === "de" ? "Dienstleistungen" : "Services" },
    { id: "about", name: language === "de" ? "Über uns" : "About" },
    { id: "features", name: language === "de" ? "Funktionen" : "Features" },
    { id: "contact", name: language === "de" ? "Kontakt" : "Contact" },
  ]

  const services = [
    {
      title: "Personal Banking",
      description: "Comprehensive banking solutions tailored to your personal financial needs and goals.",
      icon: <User className="h-6 w-6" />,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1746-y1gN3fQNTKePIFtExx2XOpO48z981w.jpeg", // Professional man with banking setup
      features: ["Premium Checking Accounts", "High-Yield Savings", "Personal Loans", "Credit Cards"],
    },
    {
      title: "Business Banking",
      description: "Advanced financial services designed to help your business grow and succeed globally.",
      icon: <Building className="h-6 w-6" />,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1745-akWLYN92zSWZRHjJYBWONaGNmLI9LW.jpeg", // Professional woman with tablet
      features: ["Business Accounts", "Commercial Lending", "Cash Management", "Trade Finance"],
    },
    {
      title: "Investment Services",
      description: "Expert investment guidance and portfolio management for long-term wealth building.",
      icon: <TrendingUp className="h-6 w-6" />,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1747-7VIVVkpvUbUVsKvZDFtcSWDGlvqKMZ.jpeg", // Professional woman with investment tools
      features: ["Portfolio Management", "Investment Advisory", "Retirement Planning", "Wealth Management"],
    },
    {
      title: "Digital Banking",
      description: "Cutting-edge digital solutions for seamless banking experiences anywhere, anytime.",
      icon: <Smartphone className="h-6 w-6" />,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1744-K2KPvoSs1GP0Dc4rbbPQTCNYcBUC7v.jpeg", // Professional man with digital banking
      features: ["Mobile Banking", "Online Transfers", "Digital Payments", "Account Management"],
    },
  ]

  const features = [
    {
      title: language === "de" ? "Höchste Sicherheit" : "Maximum Security",
      description:
        language === "de"
          ? "Modernste Verschlüsselung und biometrische Authentifizierung"
          : "State-of-the-art encryption and biometric authentication",
      icon: <Shield className="h-12 w-12" />,
    },
    {
      title: language === "de" ? "Globale Präsenz" : "Global Presence",
      description:
        language === "de"
          ? "Über 45 Länder weltweit mit lokaler Expertise"
          : "Over 45 countries worldwide with local expertise",
      icon: <Globe className="h-12 w-12" />,
    },
    {
      title: language === "de" ? "Mobile Banking" : "Mobile Banking",
      description:
        language === "de"
          ? "Intuitive Apps für iOS und Android mit allen Funktionen"
          : "Intuitive iOS and Android apps with full functionality",
      icon: <Smartphone className="h-12 w-12" />,
    },
    {
      title: language === "de" ? "24/7 Support" : "24/7 Support",
      description:
        language === "de"
          ? "Rund um die Uhr verfügbarer Kundensupport in Ihrer Sprache"
          : "Round-the-clock customer support in your language",
      icon: <HeadphonesIcon className="h-12 w-12" />,
    },
  ]

  const testimonials = [
    {
      name: "Sarah Mitchell",
      role: "CEO, TechVentures Ltd",
      content:
        "Deutsche Global Bank has been instrumental in our company's international expansion. Their trade finance solutions and expert guidance have enabled us to enter new markets with confidence.",
      rating: 5,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1745-akWLYN92zSWZRHjJYBWONaGNmLI9LW.jpeg",
    },
    {
      name: "Michael Chen",
      role: "Investment Portfolio Manager",
      content:
        "The wealth management team at Deutsche Global Bank provides exceptional service. Their strategic insights have consistently delivered strong returns for our investment portfolio.",
      rating: 5,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1744-K2KPvoSs1GP0Dc4rbbPQTCNYcBUC7v.jpeg",
    },
    {
      name: "Emma Rodriguez",
      role: "Small Business Owner",
      content:
        "From business loans to cash management solutions, Deutsche Global Bank understands the unique needs of growing businesses. Their support has been invaluable to our success.",
      rating: 5,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1751-IqXjrmmeT6wgAjsKVIllKcaO38kM7I.jpeg",
    },
  ]

  const newsItems = [
    {
      title: "Deutsche Global Bank Expands Digital Banking Platform",
      excerpt:
        "New enhanced mobile banking features now available to all customers, including advanced security protocols and streamlined international transfers.",
      date: "December 15, 2024",
      category: "Digital Innovation",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1746-y1gN3fQNTKePIFtExx2XOpO48z981w.jpeg",
    },
    {
      title: "Record Growth in Business Banking Services",
      excerpt:
        "Deutsche Global Bank reports 40% increase in business account openings, driven by comprehensive commercial lending and trade finance solutions.",
      date: "December 10, 2024",
      category: "Business Growth",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1745-akWLYN92zSWZRHjJYBWONaGNmLI9LW.jpeg",
    },
    {
      title: "New Investment Advisory Services Launch",
      excerpt:
        "Introducing personalized wealth management solutions with dedicated advisory teams for high-net-worth individuals and institutional clients.",
      date: "December 5, 2024",
      category: "Wealth Management",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1747-7VIVVkpvUbUVsKvZDFtcSWDGlvqKMZ.jpeg",
    },
  ]

  const stats = [
    { label: language === "de" ? "Globale Kunden" : "Global Customers", value: "2.5M+" },
    { label: language === "de" ? "Länder weltweit" : "Countries Served", value: "45+" },
    { label: language === "de" ? "Jahre Exzellenz" : "Years of Excellence", value: "150+" },
    { label: language === "de" ? "Verwaltetes Vermögen" : "Assets Under Management", value: "€500Mrd+" },
  ]

  const renderHome = () => (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1746-y1gN3fQNTKePIFtExx2XOpO48z981w.jpeg"
            alt="Professional Banking Excellence"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 hero-overlay" />
        </div>

        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 hero-text-shadow">
            Banking Excellence
            <span className="block text-4xl md:text-6xl mt-2">Redefined</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl mx-auto leading-relaxed">
            Experience the future of banking with Deutsche Global Bank. Secure, innovative, and globally trusted
            financial services for individuals and businesses worldwide.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 border-0 px-8 py-4 text-lg font-semibold shadow-xl"
              style={{ color: "#ffffff" }}
              onClick={handleOpenAccount}
            >
              {t.openAccount}
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 hover:bg-white hover:text-slate-900 px-8 py-4 text-lg font-semibold bg-transparent shadow-xl transition-all duration-200"
              style={{ color: "#ffffff", borderColor: "#ffffff" }}
              onClick={handleLearnMore}
            >
              {t.learnMore}
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-serif font-bold text-blue-600 mb-2">{stat.value}</div>
                <div className="text-slate-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance text-slate-900">
              {language === "de" ? "Umfassende Banking-Lösungen" : "Comprehensive Banking Solutions"}
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto text-balance">
              {language === "de"
                ? "Von Privatkunden bis zu Unternehmenslösungen bieten wir die Finanzdienstleistungen, die Sie für Ihre Ziele benötigen."
                : "From personal banking to business solutions, we provide the financial services you need to achieve your goals."}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="group hover:shadow-2xl transition-all duration-300 border-0 bg-white shadow-lg overflow-hidden"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <div className="p-3 bg-blue-600/90 rounded-full text-white backdrop-blur-sm">{service.icon}</div>
                  </div>
                </div>
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-xl font-serif text-slate-900">{service.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <CardDescription className="text-slate-600 mb-4">{service.description}</CardDescription>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center justify-center text-sm text-slate-700">
                        <CheckCircle className="h-4 w-4 text-blue-600 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance text-slate-900">
              {language === "de" ? "Warum Deutsche Global Bank wählen" : "Why Choose Deutsche Global Bank"}
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto text-balance">
              {language === "de"
                ? "Erleben Sie Banking, das sich Ihrem Lebensstil anpasst, mit modernster Technologie und persönlichem Service."
                : "Experience banking that adapts to your lifestyle with cutting-edge technology and personalized service."}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="mx-auto mb-4 p-4 bg-blue-100 rounded-full w-fit group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-serif font-semibold mb-3 text-slate-900">{feature.title}</h3>
                <p className="text-slate-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance text-slate-900">
              {language === "de" ? "Was unsere Kunden sagen" : "What Our Customers Say"}
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto text-balance">
              {language === "de"
                ? "Vertrauen Sie auf die Erfahrungen von Millionen zufriedener Kunden weltweit."
                : "Trust the experiences of millions of satisfied customers worldwide."}
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-50 border-0 shadow-xl">
              <CardContent className="p-8 md:p-12">
                <div className="text-center">
                  <Quote className="h-12 w-12 text-blue-600 mx-auto mb-6" />
                  <blockquote className="text-xl md:text-2xl font-serif text-slate-900 mb-6 leading-relaxed">
                    "{testimonials[activeTestimonial].content}"
                  </blockquote>
                  <div className="flex items-center justify-center gap-4">
                    <img
                      src={testimonials[activeTestimonial].image || "/placeholder.svg"}
                      alt={testimonials[activeTestimonial].name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="text-left">
                      <div className="font-semibold text-slate-900">{testimonials[activeTestimonial].name}</div>
                      <div className="text-slate-600">{testimonials[activeTestimonial].role}</div>
                      <div className="flex gap-1 mt-1">
                        {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-center gap-2 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === activeTestimonial ? "bg-blue-600" : "bg-slate-300"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance text-slate-900">
              {language === "de" ? "Neueste Nachrichten" : "Latest News"}
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto text-balance">
              {language === "de"
                ? "Bleiben Sie über die neuesten Entwicklungen im Banking und Finanzwesen informiert."
                : "Stay informed about the latest developments in banking and finance."}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {newsItems.map((item, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-0 bg-white shadow-lg overflow-hidden"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-blue-600 text-white">{item.category}</Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="text-sm text-slate-500 mb-2">
                    {new Date(item.date).toLocaleDateString(language === "de" ? "de-DE" : "en-US")}
                  </div>
                  <h3 className="text-xl font-serif font-semibold mb-3 text-slate-900 group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-slate-600 mb-4">{item.excerpt}</p>
                  <Button variant="ghost" className="p-0 h-auto text-blue-600 hover:text-blue-700">
                    {language === "de" ? "Weiterlesen" : "Read More"}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Promotional Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-serif font-bold mb-6 text-slate-900">
                {language === "de" ? "Kostenloses Bankkonto in Deutschland" : "Free Bank Account in Germany"}
              </h2>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                {language === "de"
                  ? "Eröffnen Sie heute Ihr kostenloses Bankkonto und genießen Sie 7 verschiedene Kontotypen für ein reibungsloses Banking-Erlebnis. Keine versteckten Gebühren, keine Mindesteinlage."
                  : "Open your free bank account today and enjoy 7 different account types for a smooth banking experience. No hidden fees, no minimum balance requirements."}
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-slate-700">
                    {language === "de" ? "Keine monatlichen Gebühren" : "No monthly fees"}
                  </span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-slate-700">
                    {language === "de" ? "Kostenlose Debitkarte" : "Free debit card"}
                  </span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-slate-700">
                    {language === "de" ? "Online- und Mobile Banking" : "Online and mobile banking"}
                  </span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-slate-700">
                    {language === "de" ? "24/7 Kundensupport" : "24/7 customer support"}
                  </span>
                </li>
              </ul>
              <Button
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-lg"
                onClick={handleOpenAccount}
              >
                {language === "de" ? "Kostenloses Konto eröffnen" : "Open Free Account"}
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
            <div className="relative">
              <img
                src="/images/free-account-promo.jpg"
                alt="Free Bank Account Promotion"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance" style={{ color: "#ffffff" }}>
            {language === "de" ? "Bereit für Exzellenz?" : "Ready to Experience Excellence?"}
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-balance" style={{ color: "#ffffff" }}>
            {language === "de"
              ? "Schließen Sie sich Millionen von Kunden an, die der Deutsche Global Bank für ihre Finanzbedürfnisse vertrauen."
              : "Join millions of customers who trust Deutsche Global Bank for their financial needs."}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              variant="secondary"
              className="px-8 py-4 text-lg font-semibold bg-white hover:bg-slate-100"
              style={{ color: "#2563eb" }}
              onClick={handleOpenAccount}
            >
              {language === "de" ? "Heute Konto eröffnen" : "Open Account Today"}
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold bg-transparent transition-all duration-200"
              style={{ color: "#ffffff", borderColor: "#ffffff" }}
            >
              {language === "de" ? "Beratung vereinbaren" : "Schedule Consultation"}
            </Button>
          </div>
        </div>
      </section>
    </div>
  )

  const renderServices = () => (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 text-slate-900">
              {language === "de" ? "Unsere Dienstleistungen" : "Our Services"}
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              {language === "de"
                ? "Umfassende Finanzlösungen für Privatpersonen und Unternehmen, die auf Ihre individuellen Bedürfnisse zugeschnitten sind."
                : "Comprehensive financial solutions for individuals and businesses, tailored to your unique needs."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <CreditCard className="h-12 w-12 text-blue-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Girokonten" : "Checking Accounts"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Kostenlose Kontoführung, weltweite Akzeptanz und modernste Sicherheitsfeatures."
                    : "Free account management, worldwide acceptance, and state-of-the-art security features."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Keine Kontoführungsgebühren" : "No monthly fees"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Kostenlose Debitkarte" : "Free debit card"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "24/7 Online-Banking" : "24/7 online banking"}
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <TrendingUp className="h-12 w-12 text-green-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Sparkonten" : "Savings Accounts"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Attraktive Zinssätze und flexible Sparpläne für Ihre finanziellen Ziele."
                    : "Attractive interest rates and flexible savings plans for your financial goals."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Bis zu 3,5% Zinsen" : "Up to 3.5% interest"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Flexible Einzahlungen" : "Flexible deposits"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Einlagensicherung" : "Deposit protection"}
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <Building2 className="h-12 w-12 text-purple-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Unternehmenskonten" : "Business Banking"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Maßgeschneiderte Lösungen für Unternehmen jeder Größe mit professionellem Support."
                    : "Tailored solutions for businesses of all sizes with professional support."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Mehrere Benutzer" : "Multi-user access"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "API-Integration" : "API integration"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Dedicated Support" : "Dedicated support"}
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <Shield className="h-12 w-12 text-red-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Kredite & Darlehen" : "Loans & Credit"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Günstige Konditionen für Privatkredite, Immobilienfinanzierung und Geschäftskredite."
                    : "Competitive rates for personal loans, mortgages, and business credit."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Schnelle Bearbeitung" : "Fast processing"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Flexible Laufzeiten" : "Flexible terms"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Persönliche Beratung" : "Personal consultation"}
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <Globe className="h-12 w-12 text-blue-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Internationale Überweisungen" : "International Transfers"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Schnelle und sichere Geldtransfers weltweit mit transparenten Gebühren."
                    : "Fast and secure money transfers worldwide with transparent fees."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "200+ Länder" : "200+ countries"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Echtzeitüberweisung" : "Real-time transfers"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Günstige Wechselkurse" : "Competitive rates"}
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white border border-slate-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  <Smartphone className="h-12 w-12 text-green-600" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-slate-900">
                  {language === "de" ? "Mobile Banking" : "Mobile Banking"}
                </h3>
                <p className="text-slate-600 mb-4">
                  {language === "de"
                    ? "Vollständige Bankkontrolle in Ihrer Tasche mit unserer preisgekrönten App."
                    : "Complete banking control in your pocket with our award-winning app."}
                </p>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Biometrische Sicherheit" : "Biometric security"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Sofortbenachrichtigungen" : "Instant notifications"}
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {language === "de" ? "Offline-Zugriff" : "Offline access"}
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-serif font-bold mb-6 text-slate-900">
              {language === "de" ? "Bereit für den nächsten Schritt?" : "Ready for the Next Step?"}
            </h2>
            <p className="text-slate-600 mb-8 max-w-2xl mx-auto">
              {language === "de"
                ? "Entdecken Sie, wie unsere Dienstleistungen Ihr Finanzleben vereinfachen können."
                : "Discover how our services can simplify your financial life."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4"
                onClick={handleOpenAccount}
              >
                {language === "de" ? "Konto eröffnen" : "Open Account"}
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 px-8 py-4 bg-transparent"
                onClick={() => setCurrentView("contact")}
              >
                {language === "de" ? "Beratung vereinbaren" : "Schedule Consultation"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderContact = () => (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 text-slate-900">
              {language === "de" ? "Kontakt" : "Contact Us"}
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              {language === "de"
                ? "Wir sind hier, um Ihnen zu helfen. Kontaktieren Sie uns über einen der folgenden Kanäle."
                : "We're here to help. Reach out to us through any of the following channels."}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-serif font-bold mb-8 text-slate-900">
                {language === "de" ? "Kontaktinformationen" : "Contact Information"}
              </h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">{language === "de" ? "Telefon" : "Phone"}</h3>
                    <p className="text-slate-600">+49 69 910-00000</p>
                    <p className="text-sm text-slate-500">
                      {language === "de" ? "Mo-Fr: 8:00-20:00, Sa: 9:00-16:00" : "Mon-Fri: 8:00-20:00, Sat: 9:00-16:00"}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-green-100 rounded-lg">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Email</h3>
                    <p className="text-slate-600">info@deutscheglobalbank.de</p>
                    <p className="text-sm text-slate-500">
                      {language === "de" ? "Antwort innerhalb von 24 Stunden" : "Response within 24 hours"}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">
                      {language === "de" ? "Hauptsitz" : "Headquarters"}
                    </h3>
                    <p className="text-slate-600">
                      Taunusanlage 12
                      <br />
                      60325 Frankfurt am Main
                      <br />
                      Deutschland
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-red-100 rounded-lg">
                    <Clock className="h-6 w-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">
                      {language === "de" ? "Notfall-Hotline" : "Emergency Hotline"}
                    </h3>
                    <p className="text-slate-600">+49 69 910-99999</p>
                    <p className="text-sm text-slate-500">{language === "de" ? "24/7 verfügbar" : "Available 24/7"}</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <Card className="bg-white border border-slate-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-serif text-slate-900">
                    {language === "de" ? "Nachricht senden" : "Send Message"}
                  </CardTitle>
                  <CardDescription className="text-slate-600">
                    {language === "de"
                      ? "Füllen Sie das Formular aus und wir melden uns bei Ihnen."
                      : "Fill out the form and we'll get back to you."}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName" className="text-slate-700">
                        {language === "de" ? "Vorname" : "First Name"}
                      </Label>
                      <Input
                        id="firstName"
                        placeholder={language === "de" ? "Ihr Vorname" : "Your first name"}
                        className="bg-white border-slate-300 text-slate-900"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName" className="text-slate-700">
                        {language === "de" ? "Nachname" : "Last Name"}
                      </Label>
                      <Input
                        id="lastName"
                        placeholder={language === "de" ? "Ihr Nachname" : "Your last name"}
                        className="bg-white border-slate-300 text-slate-900"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-slate-700">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder={language === "de" ? "ihre.email@beispiel.de" : "your.email@example.com"}
                      className="bg-white border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subject" className="text-slate-700">
                      {language === "de" ? "Betreff" : "Subject"}
                    </Label>
                    <Select>
                      <SelectTrigger className="bg-white border-slate-300 text-slate-900">
                        <SelectValue placeholder={language === "de" ? "Wählen Sie ein Thema" : "Select a topic"} />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-200">
                        <SelectItem value="account">
                          {language === "de" ? "Kontoeröffnung" : "Account Opening"}
                        </SelectItem>
                        <SelectItem value="support">
                          {language === "de" ? "Technischer Support" : "Technical Support"}
                        </SelectItem>
                        <SelectItem value="loan">
                          {language === "de" ? "Kredit & Darlehen" : "Loans & Credit"}
                        </SelectItem>
                        <SelectItem value="business">
                          {language === "de" ? "Geschäftskunden" : "Business Banking"}
                        </SelectItem>
                        <SelectItem value="other">{language === "de" ? "Sonstiges" : "Other"}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="message" className="text-slate-700">
                      {language === "de" ? "Nachricht" : "Message"}
                    </Label>
                    <textarea
                      id="message"
                      rows={4}
                      placeholder={language === "de" ? "Ihre Nachricht..." : "Your message..."}
                      className="w-full px-3 py-2 border border-slate-300 rounded-md bg-white text-slate-900 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                    {language === "de" ? "Nachricht senden" : "Send Message"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-8">
            <h2 className="text-2xl font-serif font-bold mb-6 text-center text-slate-900">
              {language === "de" ? "Häufig gestellte Fragen" : "Frequently Asked Questions"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">
                  {language === "de" ? "Wie eröffne ich ein Konto?" : "How do I open an account?"}
                </h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Klicken Sie auf 'Konto eröffnen' und folgen Sie den einfachen Schritten. Die Kontoeröffnung dauert nur wenige Minuten."
                    : "Click 'Open Account' and follow the simple steps. Account opening takes just a few minutes."}
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">
                  {language === "de" ? "Welche Dokumente benötige ich?" : "What documents do I need?"}
                </h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Sie benötigen einen gültigen Personalausweis oder Reisepass und einen Adressnachweis."
                    : "You need a valid ID or passport and proof of address."}
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">
                  {language === "de" ? "Gibt es Kontoführungsgebühren?" : "Are there account fees?"}
                </h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Nein, unsere Girokonten sind komplett kostenfrei ohne versteckte Gebühren."
                    : "No, our checking accounts are completely free with no hidden fees."}
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">
                  {language === "de" ? "Wie sicher ist Online-Banking?" : "How secure is online banking?"}
                </h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Wir verwenden modernste Verschlüsselung und Zwei-Faktor-Authentifizierung für maximale Sicherheit."
                    : "We use state-of-the-art encryption and two-factor authentication for maximum security."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  // ... existing code for other render functions ...

  const renderAbout = () => (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 text-slate-900">
              {language === "de" ? "Über Deutsche Global Bank" : "About Deutsche Global Bank"}
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              {language === "de"
                ? "Seit über 150 Jahren vertrauen Millionen von Kunden weltweit auf unsere Expertise und Innovation im Bankwesen."
                : "For over 150 years, millions of customers worldwide have trusted our expertise and innovation in banking."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-serif font-bold mb-4 text-slate-900">
                {language === "de" ? "Unsere Mission" : "Our Mission"}
              </h2>
              <p className="text-slate-600 leading-relaxed mb-6">
                {language === "de"
                  ? "Wir ermöglichen es Menschen und Unternehmen, ihre finanziellen Ziele zu erreichen, indem wir innovative, sichere und zugängliche Bankdienstleistungen anbieten."
                  : "We empower individuals and businesses to achieve their financial goals by providing innovative, secure, and accessible banking services."}
              </p>
              <ul className="space-y-2 text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  {language === "de" ? "Kundenorientierte Lösungen" : "Customer-focused solutions"}
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  {language === "de" ? "Digitale Innovation" : "Digital innovation"}
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  {language === "de" ? "Nachhaltige Praktiken" : "Sustainable practices"}
                </li>
              </ul>
            </div>
            <div>
              <h2 className="text-2xl font-serif font-bold mb-4 text-slate-900">
                {language === "de" ? "Unsere Werte" : "Our Values"}
              </h2>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-slate-900 mb-2">{language === "de" ? "Vertrauen" : "Trust"}</h3>
                  <p className="text-sm text-slate-600">
                    {language === "de"
                      ? "Wir bauen langfristige Beziehungen durch Transparenz und Zuverlässigkeit auf."
                      : "We build long-term relationships through transparency and reliability."}
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <h3 className="font-semibold text-slate-900 mb-2">
                    {language === "de" ? "Innovation" : "Innovation"}
                  </h3>
                  <p className="text-sm text-slate-600">
                    {language === "de"
                      ? "Wir nutzen modernste Technologie, um das Banking zu revolutionieren."
                      : "We leverage cutting-edge technology to revolutionize banking."}
                  </p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h3 className="font-semibold text-slate-900 mb-2">
                    {language === "de" ? "Exzellenz" : "Excellence"}
                  </h3>
                  <p className="text-sm text-slate-600">
                    {language === "de"
                      ? "Wir streben nach höchster Qualität in allem, was wir tun."
                      : "We strive for the highest quality in everything we do."}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-8 mb-16">
            <h2 className="text-2xl font-serif font-bold mb-6 text-center text-slate-900">
              {language === "de" ? "Unsere Geschichte" : "Our History"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-3xl font-serif font-bold text-blue-600 mb-2">1870</div>
                <h3 className="font-semibold text-slate-900 mb-2">{language === "de" ? "Gründung" : "Founded"}</h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Deutsche Global Bank wurde in Frankfurt am Main gegründet."
                    : "Deutsche Global Bank was founded in Frankfurt am Main."}
                </p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-serif font-bold text-blue-600 mb-2">1995</div>
                <h3 className="font-semibold text-slate-900 mb-2">
                  {language === "de" ? "Digitalisierung" : "Digital Revolution"}
                </h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Einführung des ersten Online-Banking-Systems in Deutschland."
                    : "Launched Germany's first online banking system."}
                </p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-serif font-bold text-blue-600 mb-2">2024</div>
                <h3 className="font-semibold text-slate-900 mb-2">{language === "de" ? "KI-Banking" : "AI Banking"}</h3>
                <p className="text-sm text-slate-600">
                  {language === "de"
                    ? "Pionier im KI-gestützten personalisierten Banking."
                    : "Pioneer in AI-powered personalized banking."}
                </p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-serif font-bold mb-6 text-slate-900">
              {language === "de" ? "Bereit anzufangen?" : "Ready to Get Started?"}
            </h2>
            <p className="text-slate-600 mb-8 max-w-2xl mx-auto">
              {language === "de"
                ? "Schließen Sie sich Millionen von zufriedenen Kunden an und erleben Sie die Zukunft des Bankwesens."
                : "Join millions of satisfied customers and experience the future of banking."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4"
                onClick={handleOpenAccount}
              >
                {language === "de" ? "Konto eröffnen" : "Open Account"}
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 px-8 py-4 bg-transparent"
                onClick={() => setCurrentView("contact")}
              >
                {language === "de" ? "Kontakt aufnehmen" : "Contact Us"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderLegal = () => (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 text-balance">Legal Information</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
            Important legal information and regulatory compliance details.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          <Card className="glass border-0">
            <CardHeader>
              <CardTitle className="text-2xl font-serif">Privacy Policy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                Deutsche Global Bank is committed to protecting your privacy and personal information. We collect and
                process your data in accordance with GDPR and other applicable privacy regulations. Your information is
                used solely for providing banking services and improving your customer experience.
              </p>
            </CardContent>
          </Card>

          <Card className="glass border-0">
            <CardHeader>
              <CardTitle className="text-2xl font-serif">Terms of Service</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                By using Deutsche Global Bank services, you agree to our terms and conditions. These terms govern your
                relationship with us and outline your rights and responsibilities as a customer. Please read them
                carefully before opening an account or using our services.
              </p>
            </CardContent>
          </Card>

          <Card className="glass border-0">
            <CardHeader>
              <CardTitle className="text-2xl font-serif">Regulatory Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                Deutsche Global Bank AG is regulated by the German Federal Financial Supervisory Authority (BaFin) and
                the European Central Bank (ECB). We are a member of the German Deposit Protection Fund, ensuring your
                deposits are protected up to €100,000 per customer.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  const renderFeatures = () => (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance text-slate-900">
            {language === "de" ? "Warum Deutsche Global Bank wählen" : "Why Choose Deutsche Global Bank"}
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto text-balance">
            {language === "de"
              ? "Erleben Sie Banking, das sich Ihrem Lebensstil anpasst, mit modernster Technologie und persönlichem Service."
              : "Experience banking that adapts to your lifestyle with cutting-edge technology and personalized service."}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="mx-auto mb-4 p-4 bg-blue-100 rounded-full w-fit group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-serif font-semibold mb-3 text-slate-900">{feature.title}</h3>
              <p className="text-slate-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )

  const renderCurrentView = () => {
    switch (currentView) {
      case "home":
        return renderHome()
      case "services":
        return renderServices()
      case "about":
        return renderAbout()
      case "features":
        return renderFeatures()
      case "contact":
        return renderContact()
      case "legal":
        return renderLegal()
      default:
        return renderHome()
    }
  }

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button className="flex items-center gap-3 hover:opacity-80 transition-opacity" onClick={handleLogoClick}>
              <img
                src="/images/deutsche-bank-logo.png"
                alt="Deutsche Bank"
                className="h-10 w-auto"
                style={{
                  filter:
                    "brightness(0) saturate(100%) invert(13%) sepia(94%) saturate(7151%) hue-rotate(230deg) brightness(92%) contrast(112%)",
                  background: "transparent",
                }}
              />
              <span className="text-xl font-serif font-bold text-slate-900">Deutsche Global Bank</span>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {navigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id)}
                  className={`text-sm font-medium transition-colors hover:text-blue-600 ${
                    currentView === item.id ? "text-blue-600" : "text-slate-600"
                  }`}
                >
                  {item.name}
                </button>
              ))}
            </nav>

            <div className="hidden md:flex items-center gap-4">
              <LanguageSelector onLanguageChange={setLanguage} />
              <Button
                variant="outline"
                size="sm"
                onClick={handleSignIn}
                className="border-slate-300 text-slate-700 hover:bg-slate-50 bg-transparent"
              >
                {t.login}
              </Button>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleOpenAccount}>
                {t.signup}
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-slate-900" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-200 shadow-lg">
            <div className="container mx-auto px-4 py-4">
              <nav className="flex flex-col gap-4">
                {navigation.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentView(item.id)
                      setMobileMenuOpen(false)
                    }}
                    className={`text-left text-sm font-medium transition-colors hover:text-blue-600 ${
                      currentView === item.id ? "text-blue-600" : "text-slate-600"
                    }`}
                  >
                    {item.name}
                  </button>
                ))}
                <div className="flex flex-col gap-2 pt-4 border-t border-slate-200">
                  <LanguageSelector onLanguageChange={setLanguage} className="mb-2" />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSignIn}
                    className="border-slate-300 text-slate-700 bg-transparent"
                  >
                    {t.login}
                  </Button>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleOpenAccount}>
                    {t.signup}
                  </Button>
                </div>
              </nav>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="pt-16">{renderCurrentView()}</main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <img
                  src="/images/deutsche-bank-logo.png"
                  alt="Deutsche Bank"
                  className="h-8 w-auto"
                  style={{ filter: "brightness(0) invert(1)" }}
                />
                <span className="text-lg font-serif font-bold">Deutsche Global Bank</span>
              </div>
              <p className="text-slate-300 leading-relaxed">
                {language === "de"
                  ? "Ihr vertrauensvoller Partner für alle Finanzdienstleistungen seit 1870."
                  : "Your trusted partner for all financial services since 1870."}
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">{language === "de" ? "Dienstleistungen" : "Services"}</h3>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <button onClick={() => setCurrentView("services")} className="hover:text-white transition-colors">
                    {language === "de" ? "Girokonten" : "Checking Accounts"}
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView("services")} className="hover:text-white transition-colors">
                    {language === "de" ? "Sparkonten" : "Savings Accounts"}
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView("services")} className="hover:text-white transition-colors">
                    {language === "de" ? "Kredite" : "Loans"}
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView("services")} className="hover:text-white transition-colors">
                    {language === "de" ? "Kreditkarten" : "Credit Cards"}
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">{language === "de" ? "Unternehmen" : "Company"}</h3>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <button onClick={() => setCurrentView("about")} className="hover:text-white transition-colors">
                    {language === "de" ? "Über uns" : "About Us"}
                  </button>
                </li>
                <li>
                  <button className="hover:text-white transition-colors">
                    {language === "de" ? "Karriere" : "Careers"}
                  </button>
                </li>
                <li>
                  <button className="hover:text-white transition-colors">
                    {language === "de" ? "Presse" : "Press"}
                  </button>
                </li>
                <li>
                  <button className="hover:text-white transition-colors">
                    {language === "de" ? "Investor Relations" : "Investor Relations"}
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">{language === "de" ? "Rechtliches" : "Legal"}</h3>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <button onClick={() => setCurrentView("legal")} className="hover:text-white transition-colors">
                    {language === "de" ? "Datenschutz" : "Privacy Policy"}
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView("legal")} className="hover:text-white transition-colors">
                    {language === "de" ? "AGB" : "Terms of Service"}
                  </button>
                </li>
                <li>
                  <button className="hover:text-white transition-colors">
                    {language === "de" ? "Impressum" : "Legal Notice"}
                  </button>
                </li>
                <li>
                  <button className="hover:text-white transition-colors">
                    {language === "de" ? "Regulierung" : "Regulatory Info"}
                  </button>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-700 pt-8 text-center text-slate-400">
            <p>
              © 2024 Deutsche Global Bank AG. {language === "de" ? "Alle Rechte vorbehalten." : "All rights reserved."}
            </p>
          </div>
        </div>
      </footer>

      {/* Chat Support */}
      <ChatSupport language={language} />

      {/* Admin Login Modal */}
      <AdminLoginModal
        open={showAdminLogin}
        onOpenChange={setShowAdminLogin}
        onLogin={(username: string, password: string) => {
          setAdminCredentials({ username, password })
          handleAdminLogin()
        }}
        error={adminError}
      />
    </div>
  )
}
